package com.mail.service;

import com.mail.dto.VisitorDto;

public interface ITicketService {

	String generateTicket(VisitorDto visitorDto);

}
